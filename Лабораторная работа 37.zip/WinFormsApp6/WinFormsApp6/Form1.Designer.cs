﻿namespace WinFormsApp6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            scoreLabel = new Label();
            missesLabel = new Label();
            racket = new Panel();
            ball = new Panel();
            timer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // scoreLabel
            // 
            scoreLabel.AutoSize = true;
            scoreLabel.Location = new Point(12, 9);
            scoreLabel.Name = "scoreLabel";
            scoreLabel.Size = new Size(39, 19);
            scoreLabel.TabIndex = 0;
            scoreLabel.Text = "Счёт";
            // 
            // missesLabel
            // 
            missesLabel.AutoSize = true;
            missesLabel.Location = new Point(12, 28);
            missesLabel.Name = "missesLabel";
            missesLabel.Size = new Size(74, 19);
            missesLabel.TabIndex = 0;
            missesLabel.Text = "Потеряно:";
            // 
            // racket
            // 
            racket.BackColor = Color.White;
            racket.Location = new Point(350, 488);
            racket.Name = "racket";
            racket.Size = new Size(100, 10);
            racket.TabIndex = 1;
            // 
            // ball
            // 
            ball.BackColor = Color.White;
            ball.Location = new Point(392, 467);
            ball.Name = "ball";
            ball.Size = new Size(15, 15);
            ball.TabIndex = 2;
            // 
            // timer
            // 
            timer.Interval = 10;
            timer.Tick += timer_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(800, 510);
            Controls.Add(ball);
            Controls.Add(racket);
            Controls.Add(missesLabel);
            Controls.Add(scoreLabel);
            Font = new Font("Segoe UI", 10F);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            KeyPreview = true;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Арканоид";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            MouseMove += form1_MouseMove;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label scoreLabel;
        private Label missesLabel;
        private Panel racket;
        private Panel ball;
        private System.Windows.Forms.Timer timer;
    }
}
